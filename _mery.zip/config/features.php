<?php

return [
    'notifications_broadcast' => env('FEATURE_NOTIFICATIONS_BROADCAST', true),
];


